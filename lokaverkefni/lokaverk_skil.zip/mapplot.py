import SpinTest

def plottest(): 
    lats = [66, 65, 0, 34, -2]
    lons = [-17, 56, 0 ,22, -14]
    contries = ['Iceland','Iceland','Iceland','Iceland','Iceland']
    year = 1945
    return SpinTest.plot2D(lats,lons,contries,year)
